# hello_world

Proj25_Istishara

Check this link guys it has almost everything left we need in our project
https://www.youtube.com/watch?v=wntWeqVaaP4&list=PL78sHffDjI77iyUND7TrUOXud9NSf0eCr


For using vs vode and github:
https://www.youtube.com/watch?v=vRxfnHtCxEo


I think this is channel contains all what we need for the stuff left in our project:
https://www.youtube.com/watch?v=u13g0oJ8Pn0&list=PL78sHffDjI77iyUND7TrUOXud9NSf0eCr&index=48
