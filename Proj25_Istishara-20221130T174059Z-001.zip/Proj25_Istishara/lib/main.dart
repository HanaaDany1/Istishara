import 'package:flutter/material.dart';
import 'package:hello_world/authentication.dart';
import 'package:hello_world/home_page.dart';
import 'CSS.dart';

void main() {
  runApp(Splash_Screen());
}
