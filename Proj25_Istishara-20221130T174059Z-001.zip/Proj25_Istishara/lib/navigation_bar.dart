
import 'package:flutter/material.dart';

class NBar extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _MyNavBar();
  }
}

class _MyNavBar extends State<NBar> {

  @override
  Widget build(BuildContext context) {
    // return MaterialApp(
      debugShowCheckedModeBanner: false;
      return Scaffold(
        // bottomNavigationBar: curved
  //       bottomNavigationBar: CurvedNavigationBar(
  //   backgroundColor: Colors.blueAccent,
  //   items: <Widget>[
  //     Icon(Icons.add, size: 30),
  //     Icon(Icons.list, size: 30),
  //     Icon(Icons.compare_arrows, size: 30),
  //   ],
  //   onTap: (index) {
  //     //Handle button tap
  //   },
  // ),
  // body: Container(color: Colors.blueAccent),



    );
  }
}
